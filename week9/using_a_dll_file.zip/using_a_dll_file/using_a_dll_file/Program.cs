﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;



namespace using_a_dll_file
{
    class Program
    {
        static void Main(string[] args)
        {
            TESTDLL.MyClass c = new TESTDLL.MyClass();
            int m = c.multiply(5, 10);

            Console.WriteLine(m);

        }
    }
}
